//
//  MapOverlayView.h
//  RadarImageExample
//
//  Created by Neon Spark on 3/8/12.
//  Copyright (c) 2012 http://sugartin.info. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "MapOverlay.h"

@interface MapOverlayView : MKOverlayView

@property (nonatomic,retain) UIImage *image;

@end
