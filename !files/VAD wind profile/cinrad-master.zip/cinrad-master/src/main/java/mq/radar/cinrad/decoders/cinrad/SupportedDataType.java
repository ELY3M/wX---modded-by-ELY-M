package mq.radar.cinrad.decoders.cinrad;

public enum SupportedDataType { 
	L3RADIAL, L3RASTER, L3ALPHA, L3VAD
}
