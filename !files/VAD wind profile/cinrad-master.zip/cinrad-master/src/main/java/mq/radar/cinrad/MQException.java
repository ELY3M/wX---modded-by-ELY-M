package mq.radar.cinrad;

public class MQException extends Exception {
	private static final long serialVersionUID = -1817386139288736514L;

	public MQException(String message) {
		super(message);
	}
}
