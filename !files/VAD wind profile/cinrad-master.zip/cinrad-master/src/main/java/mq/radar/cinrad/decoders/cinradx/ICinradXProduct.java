package mq.radar.cinrad.decoders.cinradx;

public interface ICinradXProduct {

	ICinradXHeader getICinradXHeader();

}
