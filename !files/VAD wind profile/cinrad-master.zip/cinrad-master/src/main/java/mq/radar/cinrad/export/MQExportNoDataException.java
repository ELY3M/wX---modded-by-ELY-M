package mq.radar.cinrad.export;

public class MQExportNoDataException extends MQExportException {

	public MQExportNoDataException(String message) {
		super(message);
		
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7993981260092484530L;
	

}
