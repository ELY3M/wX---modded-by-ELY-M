package mq.radar.cinrad.decoders.cinrad;

public class UnSupportProductException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5495417486957479542L;
	
	public UnSupportProductException(String message) {
		super(message);
	}

}
